package com.kumarsiz.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    TextView timer, money;
    long startMillis;
    final int BG=Color.rgb(6,14,19), CARD=Color.rgb(11,26,31), CARD2=Color.rgb(14,24,31);
    final int GREEN=Color.rgb(158,245,173), TEXT=Color.rgb(240,247,245), MUTED=Color.rgb(148,166,163);

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }
    LinearLayout box(int color,float radius,int pad){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad)); l.setBackground(bg(color,radius)); return l;
    }
    void addSpace(LinearLayout p,int h){ Space s=new Space(this); p.addView(s,new LinearLayout.LayoutParams(1,dp(h))); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        startMillis=getSharedPreferences("prefs",0).getLong("start",System.currentTimeMillis());
        if(!getSharedPreferences("prefs",0).contains("start"))
            getSharedPreferences("prefs",0).edit().putLong("start",startMillis).apply();
        build();
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18),dp(18),dp(18),dp(90)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        buildHome();
        buildNav();
        setContentView(root);
        updateTimer();
    }

    void buildHome(){
        content.removeAllViews();
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout hi=new LinearLayout(this); hi.setOrientation(LinearLayout.VERTICAL);
        TextView a=tv("Merhaba!",22,TEXT); a.setTypeface(null,1); hi.addView(a);
        hi.addView(tv("Bugün kendine yatırım yap. 💪",12,MUTED));
        head.addView(hi,new LinearLayout.LayoutParams(0,-2,1));
        TextView dot=tv("●",20,GREEN); dot.setGravity(Gravity.TOP); head.addView(dot,new LinearLayout.LayoutParams(dp(30),dp(40)));
        content.addView(head);
        addSpace(content,22);

        LinearLayout hero=box(CARD,28,20);
        LinearLayout row=new LinearLayout(this);
        TextView k=tv("KUMARSIZ",13,GREEN); k.setTypeface(null,1); row.addView(k,new LinearLayout.LayoutParams(0,dp(25),1));
        TextView fire=tv("🔥 Serin Devam!",11,GREEN); row.addView(fire);
        hero.addView(row);
        timer=tv("",54,TEXT); timer.setGravity(Gravity.CENTER); timer.setTypeface(null,1);
        hero.addView(timer,new LinearLayout.LayoutParams(-1,dp(95)));
        TextView quote=tv("“Bugün verdiğin mücadele,\nyarınki özgürlüğündür.”",13,MUTED); quote.setGravity(Gravity.CENTER);
        hero.addView(quote);
        addSpace(hero,10);
        hero.addView(tv("Bu sürede kazandığın",11,MUTED));
        money=tv("0 TL",28,GREEN); money.setTypeface(null,1); hero.addView(money);
        content.addView(hero);

        addSpace(content,16);
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        String[][] cards={{"✋","Kriz Anı","İstek geldiğinde"},{"✎","Günlük","Duygularını yaz"},{"▥","İstatistik","İlerlemeni gör"},{"◎","Hedefler","Adım adım ilerle"},{"★","Başarılar","Rozetlerini topla"},{"◇","Tetikleyiciler","Neleri yönet?"}};
        for(int r=0;r<2;r++){
            LinearLayout line=new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            for(int c=0;c<3;c++){
                int idx=r*3+c; LinearLayout card=box(CARD2,16,10);
                TextView icon=tv(cards[idx][0],20, idx==0?Color.rgb(255,89,77):GREEN); card.addView(icon);
                TextView title=tv(cards[idx][1],11,TEXT); title.setTypeface(null,1); card.addView(title);
                card.addView(tv(cards[idx][2],8,MUTED));
                final int page=idx; card.setOnClickListener(v -> showPage(page));
                line.addView(card,new LinearLayout.LayoutParams(0,dp(68),1));
                if(c<2){ Space sp=new Space(this); line.addView(sp,new LinearLayout.LayoutParams(dp(8),1)); }
            }
            grid.addView(line); if(r==0)addSpace(grid,10);
        }
        content.addView(grid);
        addSpace(content,16);

        LinearLayout motiv=box(Color.rgb(10,31,23),20,16);
        TextView m=tv("Bugün dünkü halinden\ndaha güçlüsün.",17,TEXT); m.setTypeface(null,1); motiv.addView(m);
        TextView sub=tv("Yarın daha da güçlü olacaksın.",12,GREEN); motiv.addView(sub);
        TextView arrow=tv("→",32,GREEN); arrow.setGravity(Gravity.RIGHT); motiv.addView(arrow);
        content.addView(motiv);
    }

    void buildNav(){
        nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8),dp(8),dp(8),dp(8)); nav.setBackground(bg(Color.rgb(10,19,23),24));
        String[] labels={"⌂\nAna Sayfa","◷\nSayaç","◉\nKriz Anı","▥\nİstatistik","○\nProfil"};
        for(int i=0;i<labels.length;i++){
            final int p=i; TextView n=tv(labels[i],11,i==0?GREEN:MUTED); n.setGravity(Gravity.CENTER);
            n.setOnClickListener(v->showNavPage(p));
            nav.addView(n,new LinearLayout.LayoutParams(0,dp(58),1));
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(68)));
    }

    void showNavPage(int p){
        if(p==0) buildHome();
        else if(p==1) showPage(1);
        else if(p==2) showCrisis();
        else if(p==3) showStats();
        else showProfile();
    }

    void showPage(int p){
        if(p==0) showCrisis(); else if(p==1) showJournal(); else if(p==2) showStats();
        else if(p==3) showGoals(); else if(p==4) showAchievements(); else showTriggers();
    }

    void basePage(String title,String sub){
        content.removeAllViews(); TextView h=tv(title,26,TEXT); h.setTypeface(null,1); content.addView(h);
        content.addView(tv(sub,13,MUTED)); addSpace(content,18);
    }
    Button action(String text){
        Button b=new Button(this); b.setText(text); b.setTextColor(BG); b.setTextSize(14); b.setAllCaps(false);
        b.setBackground(bg(GREEN,16)); return b;
    }
    void showCrisis(){
        basePage("Kriz Anı 🆘","İstek geldiğinde önce 5 dakika kazan.");
        LinearLayout c=box(CARD,22,18);
        TextView big=tv("Şu an oynamak zorunda değilsin.",25,TEXT); big.setTypeface(null,1); c.addView(big);
        addSpace(c,12); c.addView(tv("İstek bir dalga gibidir: yükselir ve azalır. Şimdi sadece 5 dakika bekle.",14,MUTED));
        addSpace(c,20);
        Button b=action("5 dakikalık kriz modunu başlat"); c.addView(b);
        b.setOnClickListener(v->crisisTimer());
        content.addView(c);
    }
    void crisisTimer(){
        basePage("5 Dakika","Bu sürede karar verme. Sadece bekle.");
        final TextView t=tv("05:00",48,GREEN); t.setGravity(Gravity.CENTER); content.addView(t,new LinearLayout.LayoutParams(-1,dp(120)));
        final long end=System.currentTimeMillis()+300000;
        new Handler().postDelayed(new Runnable(){ public void run(){
            long left=Math.max(0,end-System.currentTimeMillis()); t.setText(String.format("%02d:%02d",left/60000,(left/1000)%60));
            if(left>0)new Handler().postDelayed(this,1000); else t.setText("İstek dalgasını atlattın. 💪");
        }},0);
    }
    void showJournal(){
        basePage("Günlük 📝","Bugün nasıl hissediyorsun?");
        EditText e=new EditText(this); e.setHint("Bugün beni tetikleyen şey…"); e.setTextColor(TEXT); e.setHintTextColor(MUTED);
        e.setMinHeight(dp(160)); e.setGravity(Gravity.TOP); e.setPadding(dp(14),dp(14),dp(14),dp(14)); e.setBackground(bg(CARD,18));
        content.addView(e);
        addSpace(content,12); Button b=action("Günlüğe kaydet"); content.addView(b);
        b.setOnClickListener(v->{getSharedPreferences("journal",0).edit().putString("last",e.getText().toString()).apply(); Toast.makeText(this,"Günlük kaydedildi.",Toast.LENGTH_SHORT).show();});
    }
    void showStats(){
        basePage("İstatistikler 📊","İlerlemeni gör.");
        LinearLayout c=box(CARD,20,18);
        c.addView(tv("Kumarsız süre",12,MUTED)); TextView x=tv(days()+" gün",34,GREEN); x.setTypeface(null,1); c.addView(x);
        addSpace(c,12); c.addView(tv("Tahmini tasarruf",12,MUTED)); c.addView(tv(savedMoney()+" TL",30,GREEN));
        addSpace(c,12); c.addView(tv("Her gün küçük bir adım, uzun vadede büyük fark yaratır.",13,TEXT));
        content.addView(c);
    }
    void showGoals(){ basePage("Hedefler 🎯","Adım adım ilerle."); simple("İlk hedef","7 gün kumarsız kal","Hedefine doğru ilerliyorsun."); }
    void showAchievements(){ basePage("Başarılar 🏆","Rozetlerini topla."); simple("İlk Rozet","24 Saat","İlk gününü tamamladığında kazanırsın."); }
    void showTriggers(){ basePage("Tetikleyiciler ◇","Seni zorlayan durumları fark et."); simple("Kayıt tut","En sık gelen tetikleyicini yaz","Örneğin stres, yalnızlık veya para kazanma düşüncesi."); }
    void simple(String a,String b,String c){
        LinearLayout box=box(CARD,20,18); box.addView(tv(a,13,MUTED)); TextView t=tv(b,22,TEXT); t.setTypeface(null,1); box.addView(t); addSpace(box,8); box.addView(tv(c,13,MUTED)); content.addView(box);
    }
    void showProfile(){
        basePage("Profil 👤","Ayarlar ve başlangıç bilgilerin.");
        simple("Başlangıç tarihi",new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(new Date(startMillis)),"Bu tarih üzerinden kumarsız süre hesaplanıyor.");
        addSpace(content,12); Button b=action("Sayacı sıfırla"); content.addView(b);
        b.setOnClickListener(v->{startMillis=System.currentTimeMillis();getSharedPreferences("prefs",0).edit().putLong("start",startMillis).apply();buildHome();});
    }
    long days(){ return TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis()-startMillis); }
    long savedMoney(){ return days()*350; }
    void updateTimer(){
        if(timer==null)return;
        long diff=Math.max(0,System.currentTimeMillis()-startMillis);
        long d=TimeUnit.MILLISECONDS.toDays(diff), h=TimeUnit.MILLISECONDS.toHours(diff)%24, m=TimeUnit.MILLISECONDS.toMinutes(diff)%60;
        timer.setText(d+" GÜN\n"+String.format(Locale.getDefault(),"%02d saat %02d dk",h,m));
        if(money!=null)money.setText(savedMoney()+" TL");
        new Handler().postDelayed(this::updateTimer,1000);
    }
}
